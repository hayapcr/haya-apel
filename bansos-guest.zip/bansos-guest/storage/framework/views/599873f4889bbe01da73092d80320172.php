<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold text-success">Data Warga</h3>
        <a href="<?php echo e(route('guest.warga.create')); ?>" class="btn btn-success rounded-pill px-3">
            <i class="bi bi-plus-circle"></i> Tambah Warga
        </a>
    </div>

    
    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3 border-0 shadow-sm rounded-4 hover-scale">
            <div class="card-body d-flex align-items-center justify-content-between flex-wrap">

                
                <div class="d-flex align-items-center me-3">
                    <div class="icon-wrapper bg-success bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-3"
                         style="width: 70px; height: 70px;">
                        <i class="bi bi-person-circle text-success" style="font-size: 2.5rem;"></i>
                    </div>

                    
                    <div>
                        <h5 class="fw-bold text-success mb-1"><?php echo e($w->nama); ?></h5>
                        <small class="d-block text-muted">No KTP: <?php echo e($w->no_ktp); ?></small>
                        <small class="d-block text-muted">Jenis Kelamin: <?php echo e($w->jenis_kelamin); ?></small>
                        <small class="d-block text-muted">Agama: <?php echo e($w->agama); ?></small>
                        <small class="d-block text-muted">Pekerjaan: <?php echo e($w->pekerjaan ?? '-'); ?></small>
                        <small class="d-block text-muted">Telepon: <?php echo e($w->telp ?? '-'); ?></small>
                        <small class="d-block text-muted">Email: <?php echo e($w->email ?? '-'); ?></small>
                    </div>
                </div>

                
                <div class="mt-3 mt-md-0 text-end">
                    <a href="<?php echo e(route('guest.warga.edit', $w->warga_id)); ?>"
                       class="btn btn-sm btn-outline-success rounded-pill me-1">
                        <i class="bi bi-pencil"></i>
                    </a>
                    <form action="<?php echo e(route('guest.warga.destroy', $w->warga_id)); ?>"
                          method="POST"
                          class="d-inline"
                          onsubmit="return confirm('Hapus data ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-outline-danger rounded-pill">
                            <i class="bi bi-trash"></i>
                        </button>
                    </form>
                </div>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="text-center text-muted mt-4">Belum ada data warga.</div>
    <?php endif; ?>
</div>


<style>
.hover-scale {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.hover-scale:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 16px rgba(0, 122, 102, 0.15);
}
.icon-wrapper {
    flex-shrink: 0;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Haya_2SIA\laragon-6.0-minimal\www\haya-apel\bansos-guest\resources\views/guest/warga/index.blade.php ENDPATH**/ ?>