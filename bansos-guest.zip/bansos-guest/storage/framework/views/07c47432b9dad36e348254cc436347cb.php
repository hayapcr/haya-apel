<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BinaDesa</title>

    
    <link href="<?php echo e(asset('assets-guest/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets-guest/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets-guest/css/main.css')); ?>" rel="stylesheet">
    
</head>

<body class="index-page">
    <!-- Header -->
    
    <header id="header" class="header sticky-top">
        <div class="topbar d-flex align-items-center dark-background">
            <div class="container d-flex justify-content-center justify-content-md-between">
                <div class="contact-info d-flex align-items-center">
                    <i class="bi bi-envelope d-flex align-items-center">
                        <a href="mailto:contact@example.com">contact@example.com</a>
                    </i>
                    <i class="bi bi-phone d-flex align-items-center ms-4"><span>+1 5589 55488 55</span></i>
                </div>
            </div>
        </div>

        <div class="branding d-flex align-items-center">
            <div class="container position-relative d-flex align-items-center justify-content-between">
                <a href="<?php echo e(route('dashboard')); ?>" class="logo d-flex align-items-center text-decoration-none">
                    <h1 class="sitename text-success fw-bold">BinaDesa</h1>
                </a>

                <nav id="navmenu" class="navmenu">
                    <ul>
                        <li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li><a href="<?php echo e(route('guest.program_bantuan.index')); ?>">Program Bantuan</a></li>
                        <li><a href="<?php echo e(route('guest.warga.index')); ?>">Data Warga</a></li>
                        <li><a href="<?php echo e(route('guest.user.index')); ?>">Data User</a></li>
                    </ul>
                    <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
                </nav>
            </div>
        </div>
    </header>
    

    
    <main class="main py-5">
        <div class="container">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
    

    
    <script src="<?php echo e(asset('assets-guest/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    
</body>
</html>
<?php /**PATH D:\Haya_2SIA\laragon-6.0-minimal\www\haya-apel\bansos-guest\resources\views/guest/layouts/main.blade.php ENDPATH**/ ?>