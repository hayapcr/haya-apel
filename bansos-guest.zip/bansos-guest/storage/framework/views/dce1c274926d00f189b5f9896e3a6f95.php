<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold text-success">Tambah User</h3>
    <a href="<?php echo e(route('guest.user.index')); ?>" class="btn btn-outline-secondary rounded-pill px-3">Kembali</a>
  </div>

  <div class="card mb-3 border-0 shadow-sm rounded-4">
    <div class="card-body">
      <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($err); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form action="<?php echo e(route('guest.user.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
          <label for="name" class="form-label fw-semibold">Nama</label>
          <input id="name" name="name" type="text" class="form-control" value="<?php echo e(old('name')); ?>" required maxlength="100">
        </div>

        <div class="mb-3">
          <label for="email" class="form-label fw-semibold">Email</label>
          <input id="email" name="email" type="email" class="form-control" value="<?php echo e(old('email')); ?>" required>
        </div>

        <div class="row">
          <div class="col-md-6 mb-3">
            <label for="password" class="form-label fw-semibold">Password</label>
            <input id="password" name="password" type="password" class="form-control" required minlength="8">
          </div>

          <div class="col-md-6 mb-3">
            <label for="password_confirmation" class="form-label fw-semibold">Konfirmasi Password</label>
            <input id="password_confirmation" name="password_confirmation" type="password" class="form-control" required minlength="8">
          </div>
        </div>

        <div class="d-flex gap-2">
          <button class="btn btn-success rounded-pill px-4">Simpan</button>
          <a href="<?php echo e(route('guest.user.index')); ?>" class="btn btn-secondary rounded-pill px-4">Batal</a>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Haya_2SIA\laragon-6.0-minimal\www\haya-apel\bansos-guest\resources\views/guest/user/create.blade.php ENDPATH**/ ?>